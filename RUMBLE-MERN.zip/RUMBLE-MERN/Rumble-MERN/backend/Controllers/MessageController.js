import MessageModel from '../Models/MessageModel.js'

export const addMessage = async (req, res) => {
    const {chatId, senderId, text} = req.body

    const message = new MessageModel({
        chatId,
        senderId,
        text
    })

    try {
        const result = await message.save()
        res.status(200).json(result)

    } catch (e) {
        res.status(500).json(e)
    }
}


export const getMessages = async (req, res) => {
    const chatId = req.query.chatId

    try {
        const result = await MessageModel.find({chatId})
        res.status(200).json(result)
    } catch (e) {
        res.status(500).json(e)
    }
}